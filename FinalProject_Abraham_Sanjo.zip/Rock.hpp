/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for ExtractableItem functions, ExtractableItem is an derived class of Item
 ********************************/
#include "ExtractableItem.hpp"
#ifndef ROCK_HPP
#define ROCK_HPP
#include <string>
#include <vector>

class Rock : public ExtractableItem{
private:
    
public:
    Rock();
    
};

#endif
