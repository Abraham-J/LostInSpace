#include "NonRepairableItem.hpp"

#include <string>
using std::string;

NonRepairableItem::NonRepairableItem(){

}


