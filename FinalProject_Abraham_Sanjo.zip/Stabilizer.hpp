/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for Stabilizer functions, Stabilizer is an derived  class of NonRepairableItems
 ********************************/
#include "RepairableItem.hpp"
#ifndef STABILIZER_HPP
#define STABILIZER_HPP


class Stabilizer : public RepairableItem{
private:
    
public:
    Stabilizer();
};

#endif
