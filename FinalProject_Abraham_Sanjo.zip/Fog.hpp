/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file of Fog class, a derived class of Space.
 ********************************/

#ifndef FOG_HPP
#define FOG_HPP
#include "Space.hpp"
#include <string>

class Fog : public Space{
    
private://Variables
    
    
public://Constructors, destructors and methods
    Fog();
};
#endif
