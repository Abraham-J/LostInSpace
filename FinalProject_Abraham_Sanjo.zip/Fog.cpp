/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Implementation file of Fog class.
 ********************************/

#include "Fog.hpp"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

Fog::Fog(){
    type = "Fog";
    character = "XXX";
}

