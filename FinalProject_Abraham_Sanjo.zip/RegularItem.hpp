/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for RegularItem functions, RegularItem is an derived class from Item
 ********************************/
#include "Item.hpp"
#ifndef REGULARITEM_HPP
#define REGULARITEM_HPP
#include <string>
#include <vector>

class RegularItem : public Item{
    protected:
    
    public: 
        RegularItem();
};

#endif
