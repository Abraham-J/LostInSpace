/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Implementation file of Station class.
 ********************************/

#include "Station.hpp"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

Station::Station(){
    type = "Station";
    character = " S ";
}

