/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for Gold functions, Gold is an derived class from RegularItem
 ********************************/
#include "RegularItem.hpp"
#ifndef GOLD_HPP
#define GOLD_HPP


class Gold : public RegularItem{
private:
    
public:
    Gold();
};

#endif
