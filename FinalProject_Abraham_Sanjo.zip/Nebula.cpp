/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Implementation file of Nebula class.
 ********************************/

#include "Nebula.hpp"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

Nebula::Nebula(){
    type = "Nebula";
    character = " : ";
    
}

