/*******************************
*Name: Sanjo Abraham
*Date: 05/31/19
*Description: Implementation file of Regular Item. essentially the same as an item
********************************/
#include "RegularItem.hpp"

RegularItem::RegularItem(){
    
}
