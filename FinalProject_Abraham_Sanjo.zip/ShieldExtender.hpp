/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for ShieldExtender functions, ShieldExtender is an derived  class of NonRepairableItems
 ********************************/
#include "RepairableItem.hpp"
#ifndef SHIELDEXTENDER_HPP
#define SHIELDEXTENDER_HPP
#include <string>
#include <vector>

class ShieldExtender : public RepairableItem{
private:
    
public:
    ShieldExtender();
};

#endif
