/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for slow read
 ********************************/

#ifndef SLOWREAD_HPP
#define SLOWREAD_HPP
#include <string>

class SlowRead{
    public:
        void readSlow(std::string, int);
};
#endif
