/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file of Station class, a derived class of Space.
 ********************************/

#ifndef STATION_HPP
#define STATION_HPP
#include "Space.hpp"
#include <string>

class Station : public Space{
    
private://Variables
    
    
public://Constructors, destructors and methods
    Station();
};
#endif
