/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for Warp functions, Wap is an derived  class of NonRepairableItems
 ********************************/
#include "NonRepairableItem.hpp"
#ifndef WARP_HPP
#define WARP_HPP
#include <string>
#include <vector>

class Warp : public NonRepairableItem{
    private:
    
    public:
    Warp();
};

#endif
