/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Implementation file of EnemySpawn class.
 ********************************/

#include "EnemySpawn.hpp"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

EnemySpawn::EnemySpawn(){
    type = "EnemySpawn";
    character = " E ";
}


