/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for Scrap functions, Scrap is an derived class from RegularItem
 ********************************/
#include "RegularItem.hpp"
#ifndef SCRAP_HPP
#define SCRAP_HPP


class Scrap : public RegularItem{
private:
    
public:
    Scrap();
};

#endif
