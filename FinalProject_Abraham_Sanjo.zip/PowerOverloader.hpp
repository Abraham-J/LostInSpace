/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for PowerOverloader functions, PowerOverloader is an derived class from UsableItem
 ********************************/
#include "UsableItem.hpp"
#ifndef POWEROVERLOADER_HPP
#define POWEROVERLOADER_HPP


class PowerOverloader : public UsableItem{
private:
    
public:
    PowerOverloader();
};

#endif
