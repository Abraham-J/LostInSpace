/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for Phaser functions, Phaser is an derived  class of RepairableItems
 ********************************/
#include "RepairableItem.hpp"
#ifndef PHASER_HPP
#define PHASER_HPP


class Phaser : public RepairableItem{
private:
    
public:
    Phaser();
};

#endif
