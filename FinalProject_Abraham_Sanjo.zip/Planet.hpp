/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file of Planet class, a derived class of Space.
 ********************************/

#ifndef PLANET_HPP
#define PLANET_HPP
#include "Space.hpp"
#include <string>

class Planet : public Space{
    
private://Variables
    
    
public://Constructors, destructors and methods
    Planet();
};
#endif
