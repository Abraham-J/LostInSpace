/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Implementation file of Debris class.
 ********************************/

#include "Debris.hpp"
#include "Space.hpp"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

Debris::Debris(){
	type = "Debris";
    character = "   ";
}

