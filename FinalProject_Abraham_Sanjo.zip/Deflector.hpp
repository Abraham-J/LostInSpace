/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for Deflector functions, Deflector is an derived class from UsableItem
 ********************************/
#include "UsableItem.hpp"
#ifndef DEFLECTOR_HPP
#define DEFLECTOR_HPP


class Deflector : public UsableItem{
private:
    
public:
    Deflector();
};

#endif
