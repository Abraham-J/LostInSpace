/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for Photon functions, Photon is an derived  class of RepairableItems
 ********************************/
#include "RepairableItem.hpp"
#ifndef PHOTON_HPP
#define PHOTON_HPP


class Photon : public RepairableItem{
private:
    
public:
    Photon();
};

#endif
