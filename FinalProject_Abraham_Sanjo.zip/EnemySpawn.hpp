/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file of EnemySpawn class, a derived class of Space.
 ********************************/

#ifndef ENEMYSPAWN_HPP
#define ENEMYSPAWN_HPP
#include "Space.hpp"
#include <string>

class EnemySpawn : public Space{
    
private://Variables
    
    
public://Constructors, destructors and methods
    EnemySpawn();
    
};
#endif
