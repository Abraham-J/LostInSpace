/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for Party functions, Party is an derived class from UsableItem
 ********************************/
#include "UsableItem.hpp"
#ifndef PARTY_HPP
#define PARTY_HPP


class Party : public UsableItem{
private:
    
public:
    Party();
};

#endif
