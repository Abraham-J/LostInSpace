/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for Radar functions, Radar is an derived  class of RepairableItems
 ********************************/
#include "RepairableItem.hpp"
#ifndef RADAR_HPP
#define RADAR_HPP


class Radar : public RepairableItem{
private:
    
public:
    Radar();
};

#endif
