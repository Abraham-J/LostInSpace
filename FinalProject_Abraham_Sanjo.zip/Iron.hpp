/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for Iron functions, Iron is an derived class from RegularItem
 ********************************/
#include "RegularItem.hpp"
#ifndef IRON_HPP
#define IRON_HPP


class Iron : public RegularItem{
private:
    
public:
    Iron();
};

#endif
