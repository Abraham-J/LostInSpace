/********************************
 *Name: Sanjo Abraham
 *Date: 05/31/19
 *Description: Header file for Commu functions, Comm is a derived class of RepairableItems
 ********************************/
#include "RepairableItem.hpp"
#include "KeyItem.hpp"
#ifndef COMM_HPP
#define COMM_HPP
#include <string>
#include <vector>

class Comm:  public RepairableItem{
private:
    
public:
    Comm();
    
};

#endif
